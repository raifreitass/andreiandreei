from graphviz import Digraph


def desenhar_afd(afd, nome_arquivo='afd_minimizado'):
    dot = Digraph(format='png')

    # Forma visual dos estados finais
    for estado in afd['estados']:
        if estado in afd['finais']:
            dot.node(estado, shape='doublecircle')
        else:
            dot.node(estado, shape='circle')

    # Estado inicial (seta sem origem)
    dot.node('', shape='none')  # estado invisível
    dot.edge('', afd['inicial'])

    # Transições
    transicoes_por_estado = {}
    for (estado, simbolo), destino in afd['transicoes'].items():
        chave = (estado, destino)
        if chave in transicoes_por_estado:
            transicoes_por_estado[chave].append(simbolo)
        else:
            transicoes_por_estado[chave] = [simbolo]

    for (origem, destino), simbolos in transicoes_por_estado.items():
        label = ",".join(simbolos)
        dot.edge(origem, destino, label=label)

    dot.render(nome_arquivo, cleanup=True)
    print(f"\n Diagrama gerado como {nome_arquivo}.png")
