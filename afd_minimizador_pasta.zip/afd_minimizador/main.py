from visualizacao import desenhar_afd
from minimizador import minimizar_afd
from validacao import validar_afd
from parser import ler_afd

afd = ler_afd('afd.txt')

print("Alfabeto:", afd['alfabeto'])
print("Estados:", afd['estados'])
print("Inicial:", afd['inicial'])
print("Finais:", afd['finais'])
print("Transições:")
for (estado, simbolo), destino in afd['transicoes'].items():
    print(f"{estado} -- {simbolo} --> {destino}")


erros = validar_afd(afd)
if erros:
    print("\n Erros encontrados no AFD:")
    for erro in erros:
        print(" -", erro)
else:
    print("\n AFD válido!")


print("\n Iniciando minimização do AFD...\n")

afd_minimizado, grupos = minimizar_afd(afd)

print("Grupos de estados equivalentes:")
for grupo in grupos:
    print(" -", grupo)

print("\n AFD Minimizado:")
print("Estados:", afd_minimizado['estados'])
print("Inicial:", afd_minimizado['inicial'])
print("Finais:", afd_minimizado['finais'])
print("Transições:")
for (estado, simbolo), destino in afd_minimizado['transicoes'].items():
    print(f"{estado} -- {simbolo} --> {destino}")


desenhar_afd(afd_minimizado)
